기본적으로 StressMyGPU.ini 파일은 %APPDATA%/StressMyGPU폴더에 생성됩니다.

모바일 또는 휴대용으로 사용하려면 StressMyGPU 작업 디렉터토리에 StressMyGPU.ini를 생성합니다.

또는 StressMyGPU.exe의 이름을 StressMyGPU_p.exe로 변경합니다.