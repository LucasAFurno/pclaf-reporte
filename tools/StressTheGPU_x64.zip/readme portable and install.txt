
By default, the StressMyGPU.ini file is created in the %APPDATA%/StressMyGPU folder.

For mobile or portable use, create the StressMyGPU.ini in the StressMyGPU working directory.

Alternatively, rename the StressMyGPU.exe to StressMyGPU_p.exe. 